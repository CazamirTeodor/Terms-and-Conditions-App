create database Best;

use Best;


create table Users(
	id_u varchar(36) primary key unique,
    id varchar(20) not null,
    pass varchar(20) not null,
    username varchar(30) not null);
        
create table Docs(
	id_d varchar(36) primary key unique,
    id_u varchar(36) not null,
    doc_name varchar(20) not null,
    doc_info varchar(2000) not null);
    
create  table Doc_Storage(
    id_doc varchar(36) primary key,
    doc_details CHAR(50),
    doc_DATA MEDIUMBLOB not null,
    doc_SIZE CHAR(50) not null,
    doc_type varchar(10) not null,
    id_d varchar(36) not null);    

alter table Doc_Storage
add constraint FK_doc
foreign key (id_d)
references Docs(id_d)
on delete cascade;

alter table Docs
add constraint FK_id_u
foreign key (id_u)
references Users(id_u)
on delete cascade;

#add user
DELIMITER //
create procedure Add_User(IN email_ varchar(50), username_ varchar(30), pass_ varchar(20))
begin
	declare user_ varchar(30);
    declare em_ varchar(30);
    set user_ = (select username from Users U where username like username_);
    set em_ = (select id from Users U where email_ like id);
    if user_ like username_ or em_ like email_
    then
		Select 'Existing_user' as '';
	else
		insert into Users(id_u, id, pass, username) values (UUID(), email_, pass_, username_);
	end if;
end//

DELIMITER ;

#add doc
DELIMITER //
create procedure Add_Doc(IN email_ varchar(20), type_ char(10), doc_info_ varchar(2000), doc_DATA_ LONGBLOB,
    doc_NAME_ CHAR(50), doc_SIZE_ int)
begin
	declare id_u_ varchar(36);
	declare id_d_ varchar(36);
    declare name_ varchar(30);
    
    set name_ = (select D.doc_name 
				from Docs D
                inner join Users U 
                on U.id_u like D.id_u 
                where D.doc_name like doc_NAME_ and D.id_d like email_);
    
    if name_ like doc_NAME_
    then
		select 'Existing_name_file' as '';
	else
        set id_u_ = (select id_u from Users where Users.id like email_);
		set id_d_ = (Select UUID());
		insert into Docs(id_d, id_u, doc_name, doc_info) values (id_d_, id_u_, doc_name_, doc_info_);
		
		insert into Doc_Storage(id_doc, doc_data, doc_size, doc_type, id_d) 
		values ((Select UUID()), doc_data_, doc_size_,type_, id_d_);
	end if;
end//

DELIMITER ;

#get users
DELIMITER //
create procedure Get_Users()
begin
	select * from Users;
end//

DELIMITER ;

#get docs
DELIMITER //
create procedure Get_Docs(email varchar(20))
begin
	declare email_ varchar(30);
    set email_ = ( select email from Users U where U.id like email );
    if email_ like email
    then
		select D.doc_name
		from Docs D
        inner join users u
        on u.id_u = D.id_u
		where U.id like email;
	else
		Select 'Email_invalid' as '';
	end if;
end//

DELIMITER ;

call Get_Docs('Cazamir@gmail.com');

#get username
DELIMITER //
create procedure Get_Username(email varchar(30))
begin
	select username from Users
    where Users.id like email;
end//

DELIMITER ;

#change password
DELIMITER //
create procedure Change_Password(email varchar(30), new_pass varchar(20))
begin
	declare id varchar(36);
    set id = (select id_u From Users where Users.id like email);
    
	update Users
    set pass = new_pass
    where id_u like id;
end//

DELIMITER ;

#change username
DELIMITER //
create procedure Change_Username(email varchar(30), new_username varchar(20))
begin
	declare id varchar(36);
    set id = (select id_u From Users where Users.id like email);
    
	update Users
    set username = new_username
    where id_u like id;
end//

DELIMITER ;

#get username by email
DELIMITER //
create procedure Check_email(email varchar(30))
begin
	declare id varchar(36);
    set id = (select id_u From Users where Users.id like email);
    
    if id = NULL
    then
		select True;
	else
		select False;
	end if;
end//

DELIMITER ;

#check credentials
DELIMITER //
create procedure Check_credentials(email_ varchar(20), pass_ varchar(20))
begin
    declare em_ varchar(30);

    set em_ = ( select id from Users U where U.id like email_ and  pass_ like U.pass);
    
    if em_ like email_ 
    then
		select 'OK' as '';
	else
		select 'Bad_credentials' as '';
    end if;
end//

delimiter ;


call Check_credentials('dasd@dmasd.com', 'dasdkams');


#get doc
DELIMITER //
create procedure Get_Doc(email varchar(20), doc_name_ varchar(50))
begin
	declare email_ varchar(30);
    set email_ = ( select id from Users U where U.id like email);
    if email_ like email
    then
		select D.doc_info, DS.doc_type, DS.doc_DATA, DS.doc_size
		From Docs D
		inner join Doc_Storage DS
		on D.id_d like DS.id_d
		inner join Users U
		on U.id_u like D.id_u
		where U.id like email and D.doc_name like doc_name_;
	else
		select "Email_not_valid" as '';
	end if;
end//

delimiter ;

drop procedure Delete_User;

#delete user
DELIMITER //
create procedure Delete_User(email varchar(20))
begin
	declare id_u_ varchar(36);
    declare id_d_ varchar(36);
    set id_u_ = ( select id from Users U where U.id like email);
    set id_d_ = ( select id_d from Docs D where D.id_u like id_u_);
    
	delete from Users U
    where U.id like email;
    
    delete from Doc_Storage DS
    where DS.id_d like id_d_;
    
    delete from Docs D
    where D.id_u like id_u_;
end//

delimiter ;

#delete doc
DELIMITER //
create procedure Delete_Doc(email varchar(20), doc_name_ varchar(20))
begin
    declare id_d_ varchar(36);
    set id_d_ = ( select id_d from Docs D where D.doc_name like doc_name_);
    
    delete from Doc_Storage DS
    where DS.id_d like id_d_;
    
    delete from Docs D
    where D.doc_name like doc_name_;
	select 'OK' as '';
end//

delimiter ;
