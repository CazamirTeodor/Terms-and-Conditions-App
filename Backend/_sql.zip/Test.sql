

CALL Add_Doc("2@gmail.com", "png", "rezumatul ala", 
		x'89504E470D0A1A0A0000000D494844520000001000000010080200000090916836000000017352474200AECE1CE90000000467414D410000B18F0BFC6105000000097048597300000EC300000EC301C76FA8640000001E49444154384F6350DAE843126220493550F1A80662426C349406472801006AC91F1040F796BD0000000049454E44AE426082',
		'Test54', 100);
        
select * from Users;

select * from Doc_Storage;

call Delete_User('2@gmail.com');

call Delete_Doc('Cazamir@gmail.com', 'Test3');

CALL Add_User('Cazamir@gmail.com','Cmir', 'sdfgrew');

CALL Add_User('2@gmail.com','fds', 'sdfgrew');

call Get_Username('Cazamir@gmail.com');

call Change_Password('Cazamir@gmail.com', 'kkjhdffghj');

call Check_credentials('diacadi@gmail.com','parola1234');

call Get_Doc('Cazamir@gmail.com', 'Test3');

select hex(LOAD_FILE("C:\Users\Ioachim\Desktop\13.jpg"));

SELECT 'The message that I want to write!' as '';

CALL Add_Doc ("Cazamir@gmail.com", "jpg", "5. itis my legal and ethical responsibilty to protect the privacy, confidentiality and security ofall medical records, proprietary information and other confidential information relating to Emerson Hospital 6. Emerson's Information Technology Resources contain various types of acivty-monitoring capabilities that document and monitor user activities, and that periodic audits are performed. Unauthorized access, use or disclosure will result in disciplinary action 2. Unauthorized access, use or disclosure is strictly prohibited. Deliberate unauthorized access o release of confidential information may make me subject to legal action and will result in termination of employment. No PHI will be dovnload to portable media unless encrypted, 10. Access to patient information by physician office staff is restricted to patients directly under the care of the Physician or physician group in which they are employed.",
 NULL, LOAD_FILE('C:\Users\Ioachim\Desktop\13.jpg'), "14", 253952);