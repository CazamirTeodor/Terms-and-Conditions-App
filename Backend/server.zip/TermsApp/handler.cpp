#include "handler.h"
#include "utils.h"
#include "sql_server.h"
#include "requests/register.h"
#include "requests/login.h"
#include "requests/logout.h"
#include "requests/delete.h"
#include "requests/send.h"
#include "requests/get_filenames.h"
#include "requests/get_specific_document.h"
#include <thread>

using json = nlohmann::json;

using namespace EY;

Handler *Handler::instance = nullptr;

Handler &Handler::getInstance()
{
    if (Handler::instance == nullptr)
        instance = new Handler;
    return *instance;
}

void Handler::deleteInstance()
{
    if (Handler::instance != nullptr)
        delete instance;
}

void Handler::addRequest(json &req, User &user)
{

    if (req["type"].get<std::string>() == "register")
    {
        std::string name, email, password;

        name = req["name"].dump();
        email = req["email"].dump();
        password = req["password"].dump();

        Request *to_add = new Register(user, name, email, password);

        locker.lock();
        requests.push_back(to_add);
        locker.unlock();

        std::cout << "\nUn request a fost adaugat. Request-uri: " << requests.size() << std::endl;
    }

    if (req["type"].get<std::string>() == "login")
    {
        std::string email, password;

        email = req["email"].dump();
        password = req["password"].dump();

        Request *to_add = new Login(user, email, password);

        locker.lock();
        requests.push_back(to_add);
        locker.unlock();

        std::cout << "\nUn request a fost adaugat. Request-uri: " << requests.size() << std::endl;
    }

    if (req["type"].get<std::string>() == "logout")
    {
        Request *to_add = new Logout(user);

        locker.lock();
        requests.push_back(to_add);
        locker.unlock();

        std::cout << "\nUn request a fost adaugat. Request-uri: " << requests.size() << std::endl;
    }

    if (req["type"].get<std::string>() == "delete")
    {
        std::string filename, email;
        filename = req["filename"].dump();
        email = req["email"].dump();

        Request *to_add = new Delete(user, filename, email);

        locker.lock();
        requests.push_back(to_add);
        locker.unlock();

        std::cout << "\nUn request a fost adaugat. Request-uri: " << requests.size() << std::endl;
    }

    if (req["type"].get<std::string>() == "getFilenames")
    {
        std::string email = req["email"].dump();
        Request *to_add = new GetFilenames(user, email);

        locker.lock();
        requests.push_back(to_add);
        locker.unlock();

        std::cout << "\nUn request a fost adaugat. Request-uri: " << requests.size() << std::endl;
    }

    if (req["type"].get<std::string>() == "send")
    {
        std::string filename, extension;
        size_t dimension;

        filename = req["filename"].dump();
        extension = req["extension"].dump();
        dimension = atoi(req["dimensions"][0].dump().c_str());

        Request *to_add = new Send(user, filename, dimension, extension);

        locker.lock();
        requests.push_back(to_add);
        locker.unlock();

        std::cout << "\nUn request a fost adaugat. Request-uri: " << requests.size() << std::endl;
    }

    if (req["type"].get<std::string>() == "getSpecificDocument")
    {
        std::string email = req["email"].dump();
        std::string filename = req["filename"].dump();

        Request *to_add = new GetSpecificDocument(user, email, filename);

        locker.lock();
        requests.push_back(to_add);
        locker.unlock();

        std::cout << "\nUn request a fost adaugat. Request-uri: " << requests.size() << std::endl;
    }
}

void Handler::solveRequests()
{
    SQLServer &sql_server = SQLServer::getInstance();
    json response;

    while (true)
    {
        if (requests.size() == 0)
        {
            std::this_thread::sleep_for(std::chrono::seconds(1));
            continue;
        }

        locker.lock();
        for (auto req : requests)
        {
            if (req->isSolved())
            {
                req->sendResponse();
                requests.erase(std::find(requests.begin(), requests.end(), req));
            }
            else
                req->solve();
        }
        locker.unlock();
    }
}
