#include "user.h"
#include <iostream>
#include "utils.h"

using namespace EY;


void User::print()
{
    std::cout << "socket: " << this->socket << std::endl;
    std::cout << "ip: " << this->ip << std::endl;
}

bool User::operator==(const User& user)
{
    if (this->socket == user.socket)
        if(this->ip == user.ip)
            return true;
    return false;
}

bool User::operator!=(const User& user)
{
    return !operator==(user);
}
