#include "document.h"
#include "user.h"

using namespace EY;

void Document::parse()
{
    std::ofstream output;
    output.open(filename + "." + extension, std::ios::out | std::ios::binary);
    output << original;
    output.close();


    // std::string command = "python3 best.py ";
    // command.append(extension == "pdf" ? "1 " : "2 ");
    // command.append(filename + "." + extension);
    // system(command.c_str());

    system("python3 best.py 1 3.pdf");

    std::ifstream result;
    result.open("out.txt", std::ios::in | std::ios::binary);

    result.seekg(std::ios::end);
    int length = result.tellg();
    result.seekg(std::ios::beg);

    char *buffer = new char[length];

    result.read(buffer, length);
    summary = buffer;

    result.close();

    std::cout << "Sumarul fisierului: " << summary << std::endl;
}

User &Document::getSender()
{
    return sender;
}

size_t Document::getSize()
{
    return size;
}

std::string Document::getName()
{
    return filename;
}

std::string Document::getExtension()
{
    return extension;
}

std::string Document::getSummary()
{
    return summary;
}

std::string Document::getOriginal()
{
    return original;
}
