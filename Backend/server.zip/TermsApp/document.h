#pragma once
#include "utils.h"
#include "user.h"

using namespace EY;

class Document
{
    User &sender;

    std::string filename;
    size_t size;
    std::string extension;

    std::string original;
    std::string summary;

public:
    Document(User &user, std::string filename, size_t size, std::string extension, std::string data) : sender(user), filename(filename), size(size), extension(extension), original(data){};
    
    size_t getSize();
    std::string getName();
    User& getSender();
    std::string getExtension();
    std::string getOriginal();
    std::string getSummary();


    void parse(); 
};