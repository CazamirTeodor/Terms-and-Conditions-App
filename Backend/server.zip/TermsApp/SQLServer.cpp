#include "sql_server.h"
#include "utils.h"
#include "request.h"

#define SQL_PORT 33060

using namespace EY;
using json = nlohmann::json;

SQLServer *SQLServer::instance = nullptr;

SQLServer &SQLServer::getInstance()
{
    if (SQLServer::instance == nullptr)
        SQLServer::instance = new SQLServer;
    return *instance;
}

void SQLServer::deleteInstance()
{
    if (SQLServer::instance != nullptr)
        delete instance;
}

SQLServer::SQLServer()
{
    std::ifstream file;
    json cfg;

    file.open("config/sql_config.json", std::ios::in);

    if (!file.is_open())
    {
        // throw no_sql_config();
        std::cout << "No SQL Config file!\n";
    }

    cfg << file;

    user = cfg["username"];
    pass = cfg["password"];
    ip = cfg["ip"];

    try
    {
        session = new mysqlx::Session(ip, SQL_PORT, user, pass);
        status = true;
    }
    catch (...)
    {
        std::cout << "Eroare la Serverul SQL.\n";
        status = false;
    }
    session->sql("USE best;").execute();
    showStatus();
}

void SQLServer::showStatus()
{
    std::cout << "SQL Server:\n";
    std::cout << "\tstatus: " << (status ? "UP" : "DOWN") << std::endl;
    std::cout << "\tip: " << ip << std::endl;
    std::cout << "\tport: " << SQL_PORT << std::endl;
    std::cout << "\tusername: " << user << std::endl;
    std::cout << "\tpassword: " << pass << std::endl;
}

void SQLServer::printResult(mysqlx::SqlResult& result)
{
    for (mysqlx::Row row : result)
    {
        for (int i = 0; i < row.colCount(); i++)
            std::cout << row[i] << " ";
        std::cout << std::endl;
    }
}

mysqlx::SqlResult SQLServer::solveQuery(std::string query)
{
    return session->sql(query).execute();
}