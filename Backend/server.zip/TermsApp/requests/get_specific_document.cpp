#include "get_specific_document.h"
#include "../sql_server.h"

using namespace EY;

void GetSpecificDocument::solve()
{
    SQLServer &sql_server = SQLServer::getInstance();
    std::string query = "CALL Get_Doc(";
    query.append(email + ",");
    query.append(filename + ");");

    mysqlx::SqlResult sql_result = sql_server.solveQuery(query);
    auto row = sql_result.fetchOne();

    json response_to_send;

    response_to_send["type"] = "getSpecificDocument";

    if (row[0].get<std::string>() == "Email_invalid")
    {
        response_to_send["message"] = "No document.";
        this->response = response_to_send.dump(4);
        this->solved = true;
        return;
    }
    else
    {
        response_to_send["summary"] = row[0];
        response_to_send["extension"] = row[1];
        response_to_send["original"] = row[2];
        

        /* code */
    }
    


    std::cout << "Raspuns final: " << response << std::endl;

    this->solved = true;
}