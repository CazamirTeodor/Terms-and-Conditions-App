#include "save.h"
#include "../server.h"

using namespace EY;

void Save::solve()
{
    Server& server = Server::getInstance();

    server.storeLastDocument(this->sender);

    this->solved = true;
}