#include "get_filenames.h"
#include "../sql_server.h"
#include <sstream>

using namespace EY;

void GetFilenames::solve()
{
    SQLServer &sql_server = SQLServer::getInstance();
    std::string query = "CALL Get_Docs(";
    query.append(email + ");");

    mysqlx::SqlResult sql_result = sql_server.solveQuery(query);
    auto resp = sql_result.fetchAll();
    json response_to_send;
    json j;
    
    response_to_send["type"] = "getFilenames";
    
   for (mysqlx::Row row : resp)
    {   
        if(row[0].get<std::string>() == "Email_invalid")
            {
                response_to_send["message"] = "No documents.";
                this->response = response_to_send.dump(4);
                this->solved = true;
                return;
            }

        j.push_back(row[0]);
    }

    response_to_send["message"] = j;

    this->response = response_to_send.dump(4);

    std::cout << "Raspuns final: " << response << std::endl;
    this->solved = true;
}