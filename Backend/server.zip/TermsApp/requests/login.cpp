#include "login.h"
#include "../sql_server.h"
#include <sstream>

using namespace EY;

void Login::solve()
{
    SQLServer &sql_server = SQLServer::getInstance();
    std::string query = "CALL Check_credentials(";
    query.append(this->email + ",");
    query.append(this->password + ");");

    mysqlx::SqlResult sql_result = sql_server.solveQuery(query);
    mysqlx::Row resp = sql_result.fetchOne();

    json response_to_send;
    std::stringstream ss;
    ss << resp[0];
    std::string res;
    ss >> res;

    if (res == "OK")
        response_to_send["message"] = "OK";
    else
        response_to_send["message"] = "Wrong username or password!";

    this->response = response_to_send.dump(4);

    std::cout << response << std::endl;
    this->solved = true;
}