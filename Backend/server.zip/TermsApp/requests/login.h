#pragma once
#include "../request.h"

using namespace EY;

class Login : public Request
{
    std::string email;
    std::string password;

public:
    Login(User &sender, std::string &email, std::string &password) : Request(ReqType(LOGIN), sender), email(email), password(password){};
    void solve();
};