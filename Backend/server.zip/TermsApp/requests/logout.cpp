#include "logout.h"
#include "../sql_server.h"
#include <sstream>

using namespace EY;

void Logout::solve()
{
    
    this->solved = true;
    this->sender.disconnect();
}