#include "send.h"
#include "../server.h"
#include "../document.h"
#include "../utils.h"

using namespace EY;
using json = nlohmann::json;

void Send::solve()
{
    Server &server = Server::getInstance();
    size_t bytesReceived;
    std::string data_to_add;

    if (this->extension == "pdf")
    {
        system("python3 best.py 1 2.pdf");

        std::ifstream result;
        result.open("out.txt", std::ios::in | std::ios::binary);
        result.seekg(std::ios::end);
        std::streampos length = result.tellg();
        result.seekg(std::ios::beg);

        char *buffer = new char[length];
        result.read(buffer, length);
        result.close();

        json to_send;
        to_send["summary"] = buffer;
        std::ifstream file;
        file.open("out_1.txt", std::ios::in | std::ios::binary);
        file.seekg(std::ios::end);
        length = file.tellg();
        file.seekg(std::ios::beg);

        buffer = new char[length];

        to_send["original"] = buffer;

        this->response = to_send.dump(4);
        this->solved = true;

        result.close();
    }
    // else
    // {
    // }

    // char buffer[2048];
    // std::string data;

    // data_to_add.clear();
    // while (data_to_add.length() <= dimension)
    // {
    //     memset(buffer, 0, 2048);
    //     bytesReceived = recv(sender.getSocket(), buffer, 2048, 0);

    //     if (bytesReceived <= 0)
    //     {
    //         std::cout << "Error at receiving file!\n";
    //     }
    //     data_to_add.append(buffer);
    //     std::cout << "CHUNK:\n"
    //               << buffer << std::endl;
    // }
    // std::cout << data_to_add << std::endl;
    // std::string nou = "{\"denumire\" :" + data_to_add + "}";
    // json list = json::parse(nou);

    // for (auto item : list)
    // {
    //     std::cout << item << std::endl;
    // }

    // Document doc(sender, filename, dimension, extension, data);

    // doc.parse();

    // server.addDocument(doc);

    // this->solved = true;
}