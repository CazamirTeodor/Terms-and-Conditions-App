#include "register.h"
#include "../sql_server.h"
#include <sstream>

using namespace EY;

void Register::solve()
{
    SQLServer &sql_server = SQLServer::getInstance();
    std::string query = "CALL Add_User(";
    query.append(this->email + ",");
    query.append(this->name + ",");
    query.append(this->password + ");");

    mysqlx::SqlResult sql_result = sql_server.solveQuery(query);
    mysqlx::Row resp = sql_result.fetchOne();

    json response_to_send;
    std::stringstream ss;
    ss << resp[0];
    std::string res;
    ss >> res;

    if (res == "Existing_user")
        response_to_send["message"] = "Existing account!";
    else
        response_to_send["message"] = "OK";

    this->response = response_to_send.dump(4);

    std::cout << response << std::endl;
    this->solved = true;
}