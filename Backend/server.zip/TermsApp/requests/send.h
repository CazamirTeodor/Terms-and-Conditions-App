#pragma once

#include "../request.h"

using namespace EY;

class Send : public Request
{
    std::string filename;
    std::string extension;
    size_t dimension;

public:
    Send(User &sender, std::string &filename, size_t &dimension, std::string &extension) : Request(ReqType(SENDFILE), sender), filename(filename), dimension(dimension), extension(extension){};
    void solve();
};