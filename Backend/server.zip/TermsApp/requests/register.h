#pragma once
#include "../request.h"

using namespace EY;

class Register : public Request
{
    std::string name;
    std::string email;
    std::string password;

public:
    Register(User &sender, std::string &name, std::string &email, std::string &password) : Request(ReqType(REGISTER), sender), name(name), email(email), password(password){};
    void solve();
};