#include "delete.h"
#include "../server.h"
#include "../document.h"

using namespace EY;

void Delete::solve()
{
    SQLServer &sql_server = SQLServer::getInstance();
    std::string query = "CALL Delete_Doc(";
    query.append(this->filename + ",");
    query.append(this->email + ");");

    std::cout << "Query:" << query << std::endl;

    mysqlx::SqlResult sql_result = sql_server.solveQuery(query);
    mysqlx::Row resp = sql_result.fetchOne();

    json response_to_send;
    std::stringstream ss;
    ss << resp[0];
    std::string res;
    ss >> res;

    if (res == "OK")
        response_to_send["message"] = "OK";
    else
        response_to_send["message"] = "Something went wrong! Try again. ";

    this->response = response_to_send.dump(4);

    std::cout << response << std::endl;
    this->solved = true;
}