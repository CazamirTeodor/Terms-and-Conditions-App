#pragma once

#include "../request.h"

using namespace EY;

class Delete : public Request
{
    std::string filename;
    std::string email;

public:
    Delete(User &sender, std::string filename, std::string email) : Request(ReqType(DELETE), sender), email(email), filename(filename){};
    void solve();
};