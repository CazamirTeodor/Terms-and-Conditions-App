#pragma once

#include "../request.h"

using namespace EY;

class GetSpecificDocument : public Request
{
    std::string email;
    std::string filename;

public:
    GetSpecificDocument(User &sender, std::string email, std::string filename) : Request(ReqType(GET), sender), email(email), filename(filename){};
    void solve();
};