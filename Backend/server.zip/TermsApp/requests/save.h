#pragma once
#include "../request.h"

using namespace EY;

class Save : public Request
{

public:
    Save(User &sender): Request(ReqType(SENDFILE), sender){};
    void solve();
};