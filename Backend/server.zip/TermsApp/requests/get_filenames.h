#pragma once
#include "../request.h"

using namespace EY;

class GetFilenames : public Request
{
    std::string email;

public:
    GetFilenames(User &sender, std::string email) : Request(ReqType(GETALL), sender), email(email){};
    void solve();
};