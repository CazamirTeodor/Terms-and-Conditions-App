#pragma once
#include "../request.h"

using namespace EY;

class Logout : public Request
{

public:
    Logout(User &sender) : Request(ReqType(LOGOUT), sender){};
    void solve();
};