#pragma once
#include <string>
#include "utils.h"

namespace EY
{
    class User
    {
        int socket;
        std::string ip;

    public:
        void print();

        User(int &sock, std::string &ip) : socket(sock), ip(ip){};
        ~User(){};

        inline int getSocket()
        {
            return socket;
        }
        inline std::string getIp()
        {
            return ip;
        }

        bool operator==(const User &user);
        bool operator!=(const User &user);
        inline void disconnect()
        {
            close(this->socket);
        }
    };

} // namespace EY