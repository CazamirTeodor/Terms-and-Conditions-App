#include <iostream>
#include "server.h"

int main()
{
    EY::Server &server = EY::Server::getInstance();
    try
    {
        server.acceptConnections();
    }
    catch (...)
    {
        server.closeServer();
    }

    return 0;
}