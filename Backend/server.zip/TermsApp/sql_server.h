#pragma once
#include <string>
#include "utils.h"
#include "request.h"

using json = nlohmann::json;

namespace EY
{

    class SQLServer
    {
        mysqlx::Session *session;
        std::string ip;
        bool status;

        std::string user;
        std::string pass;

        //bool connect();
        //void disconnect();

        //void executeQuery(Request& req);

        static SQLServer *instance;
        SQLServer();
        ~SQLServer(){};

    public:
        static SQLServer &getInstance();
        static void deleteInstance();
        void showStatus();
        void printResult(mysqlx::SqlResult &result);

        mysqlx::SqlResult solveQuery(std::string query);
    };
} // namespace EY