#pragma once
#include "user.h"

using namespace EY;

typedef enum ReqType
{
    REGISTER,
    LOGIN,
    LOGOUT,
    SENDFILE,
    SAVE,
    DELETE,
    GET,
    GETALL
};

class Request
{
protected:
    ReqType type;
    User &sender;

    bool solved = false;
    std::string response;

public:
    Request(ReqType req_type, User &sender) : type(req_type), sender(sender){};
    inline bool isSolved()
    {
        return solved;
    }

    virtual void solve() = 0;
    void sendResponse();
};