
#include "user.h"
#include "server.h"
#include "utils.h"
#include "document.h"
#include <string>
#include <errno.h>
#include <thread>

using namespace EY;
using json = nlohmann::json;

Server *Server::instance = nullptr;

Server &Server::getInstance()
{
    if (Server::instance == nullptr)
        Server::instance = new Server;

    return *instance;
}

void Server::deleteInstance()
{
    if (Server::instance != nullptr)
        delete Server::instance;
}

void Server::showStatus()
{
    std::cout << "Server: \tstatus: " << (status ? "UP" : "DOWN") << std::endl;
}

Server::Server()
{
    int rc;
    std::ifstream file;
    json cfg;

    file.open("config/server_config.json", std::ios::in);

    if (!file.is_open())
    {
        // throw no_server_config();
        std::cout << "No server config file!\n";
    }

    cfg << file;

    address.sin_family = AF_INET;
    address.sin_port = htons(cfg["port"]);
    address.sin_addr.s_addr = INADDR_ANY;

    sock = socket(AF_INET, SOCK_STREAM, 0);

    if (sock <= 0)
    {
        //throw sock_error();
        std::cout << "Socket error!\n";
    }

    rc = bind(sock, (sockaddr *)&address, sizeof(address));

    if (rc > 0)
    {
        // throw bind_error();
        std::cout << "Bind error!\n";
    }

    int max_users = cfg["maximum_users"];
    rc = listen(sock, max_users);

    if (rc > 0)
    {
        // throw listen_error();
        std::cout << "Listen erorr!\n";
    }

    std::cout << "Server is now listening on port " << htons(address.sin_port) << std::endl;
    this->status = true;

    showStatus();
}

void Server::workerThread(User &user)
{
    int rc;
    char buffer[1024];
    memset(buffer, 0, 1024);

    while (true)
    {
        memset(buffer, 0, 1024);
        rc = recv(user.getSocket(), buffer, 1024, 0);

        if (rc == -1)
        {
            std::cout << user.getIp() << " disconnected abnormally.\n";
            close(user.getSocket());
            connected_users.erase(std::find(connected_users.begin(), connected_users.end(), user));
            std::cout << "Connected users: " << connected_users.size() << std::endl;
            return;
        }
        if (rc == 0)
        {
            std::cout << user.getIp() << " disconnected normally.\n";
            close(user.getSocket());
            connected_users.erase(std::find(connected_users.begin(), connected_users.end(), user));
            std::cout << "Connected users: " << connected_users.size() << std::endl;
            return;
        }

        try
        {
            json req = json::parse(buffer);
            std::cout << req.dump(4);
            handler.addRequest(req, user);
        }
        catch (...)
        {
        }
    }
}

void Server::acceptConnections()
{
    std::cout << "My socket: " << sock << std::endl;

    std::thread slave(&Handler::solveRequests, std::ref(this->handler));
    slave.detach();

    while (true)
    {
        while (connected_users.size() < max_users)
        {
            sockaddr_in client_address;
            std::string client_ip;
            socklen_t len = sizeof(client_address);

            int client_socket = accept(this->sock, (sockaddr *)&client_address, &len);
            if (client_socket <= 0)
            {
                // throw accept_error();
                std::cout << "My socket: " << sock << std::endl;
                std::cout << "Accept error\n";
                std::cout << std::strerror(errno) << std::endl;
            }
            client_ip = inet_ntoa(client_address.sin_addr);

            std::cout << client_ip << " connected on socket " << client_socket << std::endl;

            User to_add(client_socket, client_ip);

            server_mutex.lock();
            connected_users.push_back(to_add);
            auto it = std::find(connected_users.begin(), connected_users.end(), to_add);
            server_mutex.unlock();

            std::cout << "Connected users: " << connected_users.size() << std::endl;
            std::thread slave(&Server::workerThread, this, std::ref(*it));
            slave.detach();
        }
    }
}

void Server::closeServer()
{
    close(this->sock);
    for (auto user : connected_users)
        user.disconnect();
}

void Server::addDocument(Document &doc)
{
    doc_cache.push_back(doc);
}

void Server::storeLastDocument(User &user)
{
    std::string query;
    for (auto doc : doc_cache)
    {
        if (doc.getSender().getIp() == user.getIp())
        {
        }
    }
}