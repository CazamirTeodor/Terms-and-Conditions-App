#pragma once
#include <list>
#include "utils.h"
#include "sql_server.h"
#include "handler.h"
#include "document.h"
#include "user.h"


namespace EY
{
    class Server
    {
        int sock;
        sockaddr_in address;
        bool status;
        int max_users;

        SQLServer& sql_server = SQLServer::getInstance();
        Handler& handler = Handler::getInstance();
        //Logger& logger = Logger::getInstance();

        std::list<User> connected_users;
        std::list<Document> doc_cache;

        std::mutex server_mutex;

        static Server *instance;
        Server();
        ~Server(){}

    public:
        static Server &getInstance();
        static void deleteInstance();

        void showStatus();
        void acceptConnections();
        void addDocument(Document& doc);
        void storeLastDocument(User& user);
        void workerThread(User& user);

        void closeServer();
    };
} // namespace EY