#include "request.h"
#include "utils.h"

using namespace EY;

void Request::sendResponse()
{
    int rc;
    if (this->type != LOGOUT)
    {
        rc = send(sender.getSocket(), this->response.c_str(), this->response.length(), 0);
        if (rc <= 0)
        {
            std::cout << "Eroare la trimiterea raspunsului!" << std::endl;
            this->sender.disconnect();
        }
    }
}