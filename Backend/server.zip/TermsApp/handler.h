#pragma once
#include <list>
#include "request.h"
#include "utils.h"
#include "user.h"

using namespace EY;
using json = nlohmann::json;

namespace EY
{

    class Handler
    {
        std::list<Request*> requests;

        std::mutex locker;

        static Handler *instance;

        Handler(){};
        ~Handler(){};

    public:
        void addRequest(json &req, User& user);
        void solveRequests();

        static Handler &getInstance();
        static void deleteInstance();
    };
} // namespace EY