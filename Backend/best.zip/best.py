# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""
import sys
import pytesseract


def pdf_to_text(path):
    import PyPDF2 
    import textract
    
    text = ""
    try:
        #Write a for-loop to open many files (leave a comment if you'd like to learn how).
        filename = path
        #open allows you to read the file.
        pdfFileObj = open(filename,'rb')
        #The pdfReader variable is a readable object that will be parsed.
        pdfReader = PyPDF2.PdfFileReader(pdfFileObj)
        #Discerning the number of pages will allow us to parse through all the pages.
        num_pages = pdfReader.numPages
        count = 0
        text = ""
        #The while loop will read each page.
        while count < num_pages:
            pageObj = pdfReader.getPage(count)
            count +=1
            text += pageObj.extractText()
        #This if statement exists to check if the above library returned words. It's done because PyPDF2 cannot read scanned files.
        if text != "":
           text = text
        #If the above returns as False, we run the OCR library textract to #convert scanned/image based PDF files into text.
        else:
           text = textract.process(filename, method='tesseract', language='eng')
    except:
        print("S-a intamplat o exceptie(pdf_to_text)!")
        exit
        
    return text
    

    

def image_to_text(path):
    
    text = ""
    try:
        pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract'
        image_text = pytesseract.image_to_string(path, lang='eng+ces', config='--psm 1')
            
        with open('abc.txt', 'w', encoding='utf8') as f:
            f.write(image_text)
            
        f = open('abc.txt', 'r', encoding='utf8')
        text = f.read()
    except:
        print("S-a intamplat o exceptie(image_to_text)!")
        exit
        
    return text
    



def sentence_extraction(text):
    import re
    import nltk
    import heapq
    
    try:
        f1 = open('out_1.txt', 'w')
        f = open('out.txt', 'w')
        
        f1.write(text)
        text = re.sub(r'\s+', ' ', text)
        
        
        propozitii = nltk.tokenize.sent_tokenize(text)
       
        stopwords = nltk.corpus.stopwords.words('english')
        
        word_count = len(propozitii);
        
        word_frequencies = {}
        for word in nltk.word_tokenize(text):
            if word not in stopwords:
                if word not in word_frequencies.keys():
                    word_frequencies[word] = 1
                else:
                    word_frequencies[word] += 1
    
        maximum_frequncy = max(word_frequencies.values())
    
        for word in word_frequencies.keys():
            word_frequencies[word] = (word_frequencies[word]/maximum_frequncy)
            
        sentence_scores = {}
        for sent in propozitii:
            for word in nltk.word_tokenize(sent.lower()):
                if word in word_frequencies.keys():
                    if len(sent.split(' ')) < 30:
                        if sent not in sentence_scores.keys():
                            sentence_scores[sent] = word_frequencies[word]
                        else:
                            sentence_scores[sent] += word_frequencies[word]
            
        summary_sentences = heapq.nlargest(round(word_count*0.1), sentence_scores, key=sentence_scores.get)
        summary = ' '.join(summary_sentences)
        f.write(summary)
        
    except:
        print("S-a intamplat o exceptie(sentece_extractation)!")
        exit
        
    
        
def main(cmd, path):
    if cmd == '1':
        text = pdf_to_text(path)
        sentence_extraction(text)
    elif cmd == '2':
        text = image_to_text(path)
        sentence_extraction(text)
    else:
        print("Command not found")
        
if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])